import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type RacePhase = "ready" | "countdown" | "racing" | "finished";

export interface CarState {
  id: string;
  position: [number, number, number];
  rotation: number;
  speed: number;
  currentLap: number;
  checkpointsPassed: number;
  totalProgress: number;
  isPlayer: boolean;
  finished: boolean;
  finishTime?: number;
}

interface RacingState {
  phase: RacePhase;
  countdownValue: number;
  cars: Map<string, CarState>;
  raceStartTime: number;
  totalLaps: number;
  totalCheckpoints: number;
  
  // Actions
  setPhase: (phase: RacePhase) => void;
  setCountdown: (value: number) => void;
  startRace: () => void;
  finishRace: () => void;
  resetRace: () => void;
  
  // Car management
  updateCar: (carId: string, updates: Partial<CarState>) => void;
  initializeCar: (car: CarState) => void;
  getCarsByPosition: () => CarState[];
  getPlayerPosition: () => number;
  
  // Checkpoint/lap tracking
  passCheckpoint: (carId: string, checkpointIndex: number) => void;
  completeLap: (carId: string) => void;
}

export const useRacing = create<RacingState>()(
  subscribeWithSelector((set, get) => ({
    phase: "ready",
    countdownValue: 3,
    cars: new Map(),
    raceStartTime: 0,
    totalLaps: 3,
    totalCheckpoints: 4,
    
    setPhase: (phase) => set({ phase }),
    
    setCountdown: (value) => set({ countdownValue: value }),
    
    startRace: () => {
      set({ 
        phase: "racing", 
        raceStartTime: Date.now() 
      });
    },
    
    finishRace: () => {
      set({ phase: "finished" });
    },
    
    resetRace: () => {
      const cars = new Map<string, CarState>();
      get().cars.forEach((car, id) => {
        cars.set(id, {
          ...car,
          currentLap: 1,
          checkpointsPassed: 0,
          totalProgress: 0,
          finished: false,
          finishTime: undefined,
          speed: 0,
        });
      });
      
      set({ 
        phase: "ready",
        countdownValue: 3,
        cars,
        raceStartTime: 0,
      });
    },
    
    updateCar: (carId, updates) => {
      const cars = new Map(get().cars);
      const car = cars.get(carId);
      if (car) {
        cars.set(carId, { ...car, ...updates });
        set({ cars });
      }
    },
    
    initializeCar: (car) => {
      const cars = new Map(get().cars);
      cars.set(car.id, car);
      set({ cars });
    },
    
    getCarsByPosition: () => {
      const cars = Array.from(get().cars.values());
      return cars.sort((a, b) => {
        if (a.finished && !b.finished) return -1;
        if (!a.finished && b.finished) return 1;
        if (a.finished && b.finished) {
          return (a.finishTime || 0) - (b.finishTime || 0);
        }
        return b.totalProgress - a.totalProgress;
      });
    },
    
    getPlayerPosition: () => {
      const sortedCars = get().getCarsByPosition();
      const playerIndex = sortedCars.findIndex(car => car.isPlayer);
      return playerIndex + 1;
    },
    
    passCheckpoint: (carId, checkpointIndex) => {
      const state = get();
      const car = state.cars.get(carId);
      
      if (!car || car.finished) return;
      
      const expectedCheckpoint = car.checkpointsPassed % state.totalCheckpoints;
      
      if (checkpointIndex === expectedCheckpoint) {
        const newCheckpointsPassed = car.checkpointsPassed + 1;
        const progress = car.currentLap * state.totalCheckpoints + newCheckpointsPassed;
        
        state.updateCar(carId, {
          checkpointsPassed: newCheckpointsPassed,
          totalProgress: progress,
        });
        
        if (newCheckpointsPassed >= state.totalCheckpoints) {
          state.completeLap(carId);
        }
      }
    },
    
    completeLap: (carId) => {
      const state = get();
      const car = state.cars.get(carId);
      
      if (!car || car.finished) return;
      
      const newLap = car.currentLap + 1;
      
      if (newLap > state.totalLaps) {
        state.updateCar(carId, {
          finished: true,
          finishTime: Date.now() - state.raceStartTime,
        });
        
        const allCars = Array.from(state.cars.values());
        const allFinished = allCars.every(c => c.finished);
        
        if (allFinished) {
          state.finishRace();
        }
      } else {
        state.updateCar(carId, {
          currentLap: newLap,
          checkpointsPassed: 0,
        });
      }
    },
  }))
);
