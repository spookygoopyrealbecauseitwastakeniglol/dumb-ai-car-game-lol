import { useEffect, useState } from "react";
import { useRacing } from "@/lib/stores/useRacing";

export function RaceHUD() {
  const { phase, countdownValue, cars, totalLaps, getPlayerPosition } = useRacing();
  const [position, setPosition] = useState(1);
  const [playerLap, setPlayerLap] = useState(1);
  const [playerSpeed, setPlayerSpeed] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      const playerCar = cars.get("player");
      if (playerCar) {
        setPlayerLap(playerCar.currentLap);
        setPlayerSpeed(playerCar.speed);
      }
      setPosition(getPlayerPosition());
    }, 100);
    
    return () => clearInterval(interval);
  }, [cars, getPlayerPosition]);
  
  const getPositionSuffix = (pos: number) => {
    if (pos === 1) return "st";
    if (pos === 2) return "nd";
    if (pos === 3) return "rd";
    return "th";
  };
  
  return (
    <div style={{
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      pointerEvents: "none",
      fontFamily: "Inter, sans-serif",
      color: "white",
    }}>
      {phase === "countdown" && (
        <div style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          fontSize: "120px",
          fontWeight: "bold",
          textShadow: "0 0 20px rgba(0,0,0,0.8)",
          animation: "pulse 0.5s ease-in-out",
        }}>
          {countdownValue > 0 ? countdownValue : "GO!"}
        </div>
      )}
      
      {(phase === "racing" || phase === "finished") && (
        <>
          <div style={{
            position: "absolute",
            top: "20px",
            left: "20px",
            background: "rgba(0, 0, 0, 0.7)",
            padding: "20px",
            borderRadius: "10px",
            minWidth: "200px",
          }}>
            <div style={{ fontSize: "24px", marginBottom: "10px" }}>
              <span style={{ color: "#ffd700", fontWeight: "bold" }}>
                {position}{getPositionSuffix(position)}
              </span>
              <span style={{ color: "#aaa", marginLeft: "10px" }}>/ 8</span>
            </div>
            
            <div style={{ fontSize: "18px", marginBottom: "8px" }}>
              Lap: <span style={{ fontWeight: "bold" }}>{playerLap}</span> / {totalLaps}
            </div>
            
            <div style={{ fontSize: "18px" }}>
              Speed: <span style={{ fontWeight: "bold" }}>{Math.round(playerSpeed * 10)}</span> km/h
            </div>
          </div>
          
          <div style={{
            position: "absolute",
            top: "20px",
            right: "20px",
            background: "rgba(0, 0, 0, 0.7)",
            padding: "15px 25px",
            borderRadius: "10px",
            fontSize: "16px",
            color: "#aaa",
          }}>
            <div>W/↑ - Accelerate</div>
            <div>S/↓ - Brake</div>
            <div>A/← - Turn Left</div>
            <div>D/→ - Turn Right</div>
          </div>
        </>
      )}
      
      {phase === "finished" && (
        <div style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          background: "rgba(0, 0, 0, 0.9)",
          padding: "40px 60px",
          borderRadius: "20px",
          textAlign: "center",
        }}>
          <div style={{ fontSize: "48px", fontWeight: "bold", marginBottom: "20px" }}>
            Race Finished!
          </div>
          <div style={{ fontSize: "36px", color: "#ffd700", marginBottom: "30px" }}>
            You finished {position}{getPositionSuffix(position)}
          </div>
          <div style={{ fontSize: "18px", color: "#aaa" }}>
            Press R to restart
          </div>
        </div>
      )}
    </div>
  );
}
