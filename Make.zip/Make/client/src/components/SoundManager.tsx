import { useEffect, useRef } from "react";
import { useAudio } from "@/lib/stores/useAudio";
import { useRacing } from "@/lib/stores/useRacing";

export function SoundManager() {
  const { setBackgroundMusic, setSuccessSound, isMuted, backgroundMusic } = useAudio();
  const { phase } = useRacing();
  const initialized = useRef(false);
  
  useEffect(() => {
    if (!initialized.current) {
      const bgMusic = new Audio("/sounds/background.mp3");
      bgMusic.loop = true;
      bgMusic.volume = 0.3;
      setBackgroundMusic(bgMusic);
      
      const successSound = new Audio("/sounds/success.mp3");
      successSound.volume = 0.5;
      setSuccessSound(successSound);
      
      initialized.current = true;
      console.log("Sound manager initialized");
    }
  }, [setBackgroundMusic, setSuccessSound]);
  
  useEffect(() => {
    if (!backgroundMusic) return;
    
    if (phase === "racing" && !isMuted) {
      backgroundMusic.play().catch(err => {
        console.log("Background music play prevented:", err);
      });
    } else {
      backgroundMusic.pause();
    }
  }, [phase, isMuted, backgroundMusic]);
  
  return null;
}
