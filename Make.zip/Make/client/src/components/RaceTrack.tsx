import { useTexture } from "@react-three/drei";
import * as THREE from "three";
import { useMemo } from "react";

export function RaceTrack() {
  const asphaltTexture = useTexture("/textures/asphalt.png");
  const grassTexture = useTexture("/textures/grass.png");
  
  useMemo(() => {
    asphaltTexture.wrapS = asphaltTexture.wrapT = THREE.RepeatWrapping;
    asphaltTexture.repeat.set(20, 20);
    
    grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
    grassTexture.repeat.set(50, 50);
  }, [asphaltTexture, grassTexture]);
  
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
        <planeGeometry args={[200, 200]} />
        <meshStandardMaterial map={grassTexture} />
      </mesh>
      
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <ringGeometry args={[15, 25, 64]} />
        <meshStandardMaterial map={asphaltTexture} />
      </mesh>
      
      <TrackBoundaries />
      <Checkpoints />
    </group>
  );
}

function TrackBoundaries() {
  const innerRadius = 15;
  const outerRadius = 25;
  const segments = 64;
  
  const innerBarriers = useMemo(() => {
    const barriers = [];
    for (let i = 0; i < segments; i++) {
      const angle = (i / segments) * Math.PI * 2;
      const x = Math.cos(angle) * innerRadius;
      const z = Math.sin(angle) * innerRadius;
      barriers.push({ x, z, angle });
    }
    return barriers;
  }, []);
  
  const outerBarriers = useMemo(() => {
    const barriers = [];
    for (let i = 0; i < segments; i++) {
      const angle = (i / segments) * Math.PI * 2;
      const x = Math.cos(angle) * outerRadius;
      const z = Math.sin(angle) * outerRadius;
      barriers.push({ x, z, angle });
    }
    return barriers;
  }, []);
  
  return (
    <group>
      {innerBarriers.map((barrier, i) => (
        <mesh
          key={`inner-${i}`}
          position={[barrier.x, 0.5, barrier.z]}
          rotation={[0, barrier.angle + Math.PI / 2, 0]}
          castShadow
        >
          <boxGeometry args={[0.3, 1, 0.5]} />
          <meshStandardMaterial color="#ff0000" />
        </mesh>
      ))}
      
      {outerBarriers.map((barrier, i) => (
        <mesh
          key={`outer-${i}`}
          position={[barrier.x, 0.5, barrier.z]}
          rotation={[0, barrier.angle + Math.PI / 2, 0]}
          castShadow
        >
          <boxGeometry args={[0.3, 1, 0.5]} />
          <meshStandardMaterial color="#ff0000" />
        </mesh>
      ))}
    </group>
  );
}

function Checkpoints() {
  const checkpointPositions = useMemo(() => {
    const radius = 20;
    const positions = [];
    for (let i = 0; i < 4; i++) {
      const angle = (i / 4) * Math.PI * 2;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      positions.push({ x, z, angle, index: i });
    }
    return positions;
  }, []);
  
  return (
    <group>
      {checkpointPositions.map((cp) => (
        <mesh
          key={cp.index}
          position={[cp.x, 2, cp.z]}
          rotation={[0, cp.angle + Math.PI / 2, 0]}
          userData={{ checkpointIndex: cp.index }}
        >
          <boxGeometry args={[0.2, 4, 10]} />
          <meshStandardMaterial
            color={cp.index === 0 ? "#00ff00" : "#ffff00"}
            transparent
            opacity={0.3}
          />
        </mesh>
      ))}
    </group>
  );
}

export function getTrackPath(progress: number): { x: number; z: number; angle: number } {
  const radius = 20;
  const angle = progress * Math.PI * 2;
  const x = Math.cos(angle) * radius;
  const z = Math.sin(angle) * radius;
  return { x, z, angle: angle + Math.PI / 2 };
}

export function getCheckpointPositions() {
  const radius = 20;
  const positions = [];
  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * Math.PI * 2;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    positions.push({ x, z, index: i });
  }
  return positions;
}
