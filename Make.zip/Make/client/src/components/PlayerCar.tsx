import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { useRacing } from "@/lib/stores/useRacing";
import { getCheckpointPositions } from "./RaceTrack";
import { getCarBoundingBox, checkAABBCollision, resolveCollision } from "@/lib/collision";

enum Controls {
  forward = "forward",
  backward = "backward",
  left = "left",
  right = "right",
}

export function PlayerCar() {
  const meshRef = useRef<THREE.Mesh>(null);
  const [, getKeys] = useKeyboardControls<Controls>();
  
  const velocity = useRef(0);
  const angle = useRef(0);
  const position = useRef(new THREE.Vector3(20, 0.5, 0));
  
  const { phase, updateCar, passCheckpoint, initializeCar, cars } = useRacing();
  const checkpointPositions = useRef(getCheckpointPositions());
  const lastCheckpointPassed = useRef(-1);
  
  useEffect(() => {
    initializeCar({
      id: "player",
      position: [20, 0.5, 0],
      rotation: Math.PI / 2,
      speed: 0,
      currentLap: 1,
      checkpointsPassed: 0,
      totalProgress: 0,
      isPlayer: true,
      finished: false,
    });
    
    console.log("Player car initialized");
  }, [initializeCar]);
  
  useFrame((_, delta) => {
    if (!meshRef.current) return;
    
    if (phase === "racing") {
      const { forward, backward, left, right } = getKeys();
      
      const maxSpeed = 30;
      const acceleration = 15;
      const braking = 20;
      const friction = 5;
      const turnSpeed = 2;
      
      if (forward) {
        velocity.current = Math.min(velocity.current + acceleration * delta, maxSpeed);
      } else if (backward) {
        velocity.current = Math.max(velocity.current - braking * delta, -maxSpeed * 0.5);
      } else {
        if (velocity.current > 0) {
          velocity.current = Math.max(0, velocity.current - friction * delta);
        } else {
          velocity.current = Math.min(0, velocity.current + friction * delta);
        }
      }
      
      if (Math.abs(velocity.current) > 0.1) {
        if (left) {
          angle.current += turnSpeed * delta * (velocity.current > 0 ? 1 : -1);
        }
        if (right) {
          angle.current -= turnSpeed * delta * (velocity.current > 0 ? 1 : -1);
        }
      }
      
      const moveX = Math.cos(angle.current) * velocity.current * delta;
      const moveZ = Math.sin(angle.current) * velocity.current * delta;
      
      position.current.x += moveX;
      position.current.z += moveZ;
      
      const distFromCenter = Math.sqrt(
        position.current.x * position.current.x + 
        position.current.z * position.current.z
      );
      
      if (distFromCenter < 15.5) {
        const pushAngle = Math.atan2(position.current.z, position.current.x);
        position.current.x = Math.cos(pushAngle) * 15.5;
        position.current.z = Math.sin(pushAngle) * 15.5;
        velocity.current *= 0.5;
      } else if (distFromCenter > 24.5) {
        const pushAngle = Math.atan2(position.current.z, position.current.x);
        position.current.x = Math.cos(pushAngle) * 24.5;
        position.current.z = Math.sin(pushAngle) * 24.5;
        velocity.current *= 0.5;
      }
      
      const playerBox = getCarBoundingBox(
        [position.current.x, position.current.y, position.current.z],
        angle.current
      );
      
      cars.forEach((car, carId) => {
        if (carId !== "player") {
          const aiBox = getCarBoundingBox(car.position, car.rotation);
          
          if (checkAABBCollision(playerBox, aiBox)) {
            console.log(`Collision detected with ${carId}`);
            const collision = resolveCollision(
              [position.current.x, position.current.y, position.current.z],
              car.position,
              velocity.current
            );
            
            velocity.current = collision.newVelocity;
            position.current.x += collision.pushX;
            position.current.z += collision.pushZ;
          }
        }
      });
      
      meshRef.current.position.copy(position.current);
      meshRef.current.rotation.y = angle.current;
      
      updateCar("player", {
        position: [position.current.x, position.current.y, position.current.z],
        rotation: angle.current,
        speed: Math.abs(velocity.current),
      });
      
      checkpointPositions.current.forEach((cp) => {
        const dist = Math.sqrt(
          (position.current.x - cp.x) ** 2 + 
          (position.current.z - cp.z) ** 2
        );
        
        if (dist < 5 && lastCheckpointPassed.current !== cp.index) {
          console.log(`Player passed checkpoint ${cp.index}`);
          passCheckpoint("player", cp.index);
          lastCheckpointPassed.current = cp.index;
        }
      });
    } else if (phase === "ready" || phase === "countdown") {
      position.current.set(20, 0.5, 0);
      angle.current = Math.PI / 2;
      velocity.current = 0;
      lastCheckpointPassed.current = -1;
      
      if (meshRef.current) {
        meshRef.current.position.copy(position.current);
        meshRef.current.rotation.y = angle.current;
      }
    }
  });
  
  return (
    <mesh ref={meshRef} position={[20, 0.5, 0]} castShadow receiveShadow>
      <boxGeometry args={[1.5, 0.8, 3]} />
      <meshStandardMaterial color="#0066ff" />
      
      <mesh position={[0, 0.6, 1]}>
        <boxGeometry args={[1.2, 0.5, 1]} />
        <meshStandardMaterial color="#3388ff" />
      </mesh>
    </mesh>
  );
}
