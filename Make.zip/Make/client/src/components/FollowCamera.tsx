import { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useRacing } from "@/lib/stores/useRacing";

export function FollowCamera() {
  const { camera } = useThree();
  const { cars } = useRacing();
  
  const targetPosition = useRef(new THREE.Vector3());
  const currentPosition = useRef(new THREE.Vector3(20, 8, -8));
  const lookAtPosition = useRef(new THREE.Vector3());
  
  useFrame(() => {
    const playerCar = cars.get("player");
    
    if (playerCar) {
      const [x, y, z] = playerCar.position;
      const rotation = playerCar.rotation;
      
      const distance = 12;
      const height = 6;
      
      const offsetX = -Math.cos(rotation) * distance;
      const offsetZ = -Math.sin(rotation) * distance;
      
      targetPosition.current.set(x + offsetX, y + height, z + offsetZ);
      
      currentPosition.current.lerp(targetPosition.current, 0.1);
      
      lookAtPosition.current.set(x, y + 1, z);
      
      camera.position.copy(currentPosition.current);
      camera.lookAt(lookAtPosition.current);
    } else {
      camera.position.set(20, 15, -15);
      camera.lookAt(0, 0, 0);
    }
  });
  
  return null;
}
