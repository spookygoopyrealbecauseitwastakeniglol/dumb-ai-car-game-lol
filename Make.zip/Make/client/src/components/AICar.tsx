import { useRef, useEffect, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useRacing } from "@/lib/stores/useRacing";
import { getCheckpointPositions } from "./RaceTrack";
import { getCarBoundingBox, checkAABBCollision, resolveCollision } from "@/lib/collision";

interface AICarProps {
  id: string;
  startOffset: number;
  color: string;
  baseSpeed: number;
}

export function AICar({ id, startOffset, color, baseSpeed }: AICarProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  const progress = useRef(startOffset);
  const speed = useRef(baseSpeed);
  const radius = 20;
  
  const { phase, updateCar, passCheckpoint, initializeCar, cars } = useRacing();
  const checkpointPositions = useRef(getCheckpointPositions());
  const lastCheckpointPassed = useRef(-1);
  
  const initialPosition = useMemo(() => {
    const angle = startOffset * Math.PI * 2;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    return { x, z, angle: angle + Math.PI / 2 };
  }, [startOffset]);
  
  useEffect(() => {
    initializeCar({
      id,
      position: [initialPosition.x, 0.5, initialPosition.z],
      rotation: initialPosition.angle,
      speed: 0,
      currentLap: 1,
      checkpointsPassed: 0,
      totalProgress: 0,
      isPlayer: false,
      finished: false,
    });
    
    console.log(`AI car ${id} initialized at offset ${startOffset}`);
  }, [id, startOffset, initialPosition, initializeCar]);
  
  useFrame((_, delta) => {
    if (!meshRef.current) return;
    
    if (phase === "racing") {
      const currentCar = cars.get(id);
      if (currentCar?.finished) {
        speed.current = Math.max(0, speed.current - 10 * delta);
      } else {
        speed.current = baseSpeed + Math.sin(Date.now() * 0.001 + parseFloat(id.split('-')[1] || '0')) * 2;
      }
      
      progress.current += (speed.current / radius) * delta;
      progress.current = progress.current % 1;
      
      let angle = progress.current * Math.PI * 2;
      let x = Math.cos(angle) * radius;
      let z = Math.sin(angle) * radius;
      const rotationAngle = angle + Math.PI / 2;
      
      const aiBox = getCarBoundingBox([x, 0.5, z], rotationAngle);
      
      cars.forEach((car, carId) => {
        if (carId !== id) {
          const otherBox = getCarBoundingBox(car.position, car.rotation);
          
          if (checkAABBCollision(aiBox, otherBox)) {
            const collision = resolveCollision(
              [x, 0.5, z],
              car.position,
              speed.current
            );
            
            speed.current = collision.newVelocity;
            x += collision.pushX;
            z += collision.pushZ;
          }
        }
      });
      
      meshRef.current.position.set(x, 0.5, z);
      meshRef.current.rotation.y = rotationAngle;
      
      updateCar(id, {
        position: [x, 0.5, z],
        rotation: rotationAngle,
        speed: speed.current,
      });
      
      checkpointPositions.current.forEach((cp) => {
        const dist = Math.sqrt((x - cp.x) ** 2 + (z - cp.z) ** 2);
        
        if (dist < 5 && lastCheckpointPassed.current !== cp.index) {
          passCheckpoint(id, cp.index);
          lastCheckpointPassed.current = cp.index;
        }
      });
    } else if (phase === "ready" || phase === "countdown") {
      progress.current = startOffset;
      speed.current = 0;
      lastCheckpointPassed.current = -1;
      
      const angle = startOffset * Math.PI * 2;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      
      if (meshRef.current) {
        meshRef.current.position.set(x, 0.5, z);
        meshRef.current.rotation.y = angle + Math.PI / 2;
      }
    }
  });
  
  return (
    <mesh 
      ref={meshRef} 
      position={[initialPosition.x, 0.5, initialPosition.z]}
      rotation={[0, initialPosition.angle, 0]}
      castShadow 
      receiveShadow
    >
      <boxGeometry args={[1.5, 0.8, 3]} />
      <meshStandardMaterial color={color} />
      
      <mesh position={[0, 0.6, 1]}>
        <boxGeometry args={[1.2, 0.5, 1]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.2} />
      </mesh>
    </mesh>
  );
}

export function AICars() {
  const aiCars = useMemo(() => [
    { id: "ai-1", startOffset: 0.05, color: "#ff0000", baseSpeed: 12 },
    { id: "ai-2", startOffset: 0.08, color: "#00ff00", baseSpeed: 11 },
    { id: "ai-3", startOffset: 0.11, color: "#ffff00", baseSpeed: 13 },
    { id: "ai-4", startOffset: 0.14, color: "#ff00ff", baseSpeed: 10 },
    { id: "ai-5", startOffset: 0.17, color: "#00ffff", baseSpeed: 12.5 },
    { id: "ai-6", startOffset: 0.20, color: "#ff8800", baseSpeed: 11.5 },
    { id: "ai-7", startOffset: 0.23, color: "#8800ff", baseSpeed: 12.8 },
  ], []);
  
  return (
    <>
      {aiCars.map((car) => (
        <AICar key={car.id} {...car} />
      ))}
    </>
  );
}
