export interface BoundingBox {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export function getCarBoundingBox(
  position: [number, number, number],
  rotation: number,
  width: number = 1.5,
  length: number = 3
): BoundingBox {
  const [x, , z] = position;
  
  const cos = Math.cos(rotation);
  const sin = Math.sin(rotation);
  
  const halfWidth = width / 2;
  const halfLength = length / 2;
  
  const corners = [
    { x: -halfWidth, z: -halfLength },
    { x: halfWidth, z: -halfLength },
    { x: -halfWidth, z: halfLength },
    { x: halfWidth, z: halfLength },
  ];
  
  const rotatedCorners = corners.map(corner => ({
    x: x + corner.x * cos - corner.z * sin,
    z: z + corner.x * sin + corner.z * cos,
  }));
  
  const minX = Math.min(...rotatedCorners.map(c => c.x));
  const maxX = Math.max(...rotatedCorners.map(c => c.x));
  const minZ = Math.min(...rotatedCorners.map(c => c.z));
  const maxZ = Math.max(...rotatedCorners.map(c => c.z));
  
  return { minX, maxX, minZ, maxZ };
}

export function checkAABBCollision(box1: BoundingBox, box2: BoundingBox): boolean {
  return (
    box1.minX < box2.maxX &&
    box1.maxX > box2.minX &&
    box1.minZ < box2.maxZ &&
    box1.maxZ > box2.minZ
  );
}

export function resolveCollision(
  pos1: [number, number, number],
  pos2: [number, number, number],
  velocity1: number,
  minSeparation: number = 4
): { newVelocity: number; pushX: number; pushZ: number } {
  const dx = pos1[0] - pos2[0];
  const dz = pos1[2] - pos2[2];
  const distance = Math.sqrt(dx * dx + dz * dz);
  
  if (distance === 0) {
    return { newVelocity: velocity1 * 0.5, pushX: 0.5, pushZ: 0 };
  }
  
  const overlap = minSeparation - distance;
  
  if (overlap <= 0) {
    return { newVelocity: velocity1, pushX: 0, pushZ: 0 };
  }
  
  const pushX = (dx / distance) * overlap * 0.5;
  const pushZ = (dz / distance) * overlap * 0.5;
  
  const newVelocity = velocity1 * 0.3;
  
  return { newVelocity, pushX, pushZ };
}
