import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect } from "react";
import { KeyboardControls } from "@react-three/drei";
import "@fontsource/inter";
import { RaceTrack } from "./components/RaceTrack";
import { PlayerCar } from "./components/PlayerCar";
import { AICars } from "./components/AICar";
import { FollowCamera } from "./components/FollowCamera";
import { RaceHUD } from "./components/RaceHUD";
import { SoundManager } from "./components/SoundManager";
import { useRacing } from "./lib/stores/useRacing";
import { useAudio } from "./lib/stores/useAudio";

enum Controls {
  forward = "forward",
  backward = "backward",
  left = "left",
  right = "right",
}

const keyMap = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.left, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.right, keys: ["KeyD", "ArrowRight"] },
];

function Lights() {
  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[10, 20, 10]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-50}
        shadow-camera-right={50}
        shadow-camera-top={50}
        shadow-camera-bottom={-50}
      />
      <hemisphereLight
        args={["#87ceeb", "#654321", 0.3]}
      />
    </>
  );
}

function GameController() {
  const { phase, setPhase, setCountdown, startRace, resetRace } = useRacing();
  const { toggleMute, isMuted } = useAudio();
  
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === " " && phase === "ready") {
        e.preventDefault();
        console.log("Starting countdown...");
        setPhase("countdown");
        
        let count = 3;
        setCountdown(count);
        
        const interval = setInterval(() => {
          count--;
          if (count > 0) {
            setCountdown(count);
          } else if (count === 0) {
            setCountdown(0);
            setTimeout(() => {
              console.log("Race started!");
              startRace();
            }, 500);
          }
          
          if (count < 0) {
            clearInterval(interval);
          }
        }, 1000);
      }
      
      if (e.key.toLowerCase() === "r" && phase === "finished") {
        console.log("Restarting race...");
        resetRace();
      }
      
      if (e.key.toLowerCase() === "m") {
        toggleMute();
      }
    };
    
    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [phase, setPhase, setCountdown, startRace, resetRace, toggleMute]);
  
  return (
    <>
      {phase === "ready" && (
        <div style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          background: "rgba(0, 0, 0, 0.8)",
          padding: "40px 60px",
          borderRadius: "20px",
          textAlign: "center",
          color: "white",
          fontFamily: "Inter, sans-serif",
          pointerEvents: "none",
        }}>
          <div style={{ fontSize: "48px", fontWeight: "bold", marginBottom: "20px" }}>
            Racing Game
          </div>
          <div style={{ fontSize: "24px", marginBottom: "30px", color: "#aaa" }}>
            Press SPACE to start the race
          </div>
          <div style={{ fontSize: "16px", color: "#666" }}>
            Press M to {isMuted ? "unmute" : "mute"} sound
          </div>
        </div>
      )}
    </>
  );
}

function App() {
  return (
    <div style={{ width: "100vw", height: "100vh", position: "relative", overflow: "hidden" }}>
      <KeyboardControls map={keyMap}>
        <Canvas
          shadows
          camera={{
            position: [20, 15, -15],
            fov: 60,
            near: 0.1,
            far: 1000,
          }}
          gl={{
            antialias: true,
            powerPreference: "default",
          }}
        >
          <color attach="background" args={["#87ceeb"]} />
          
          <Lights />
          
          <Suspense fallback={null}>
            <RaceTrack />
            <PlayerCar />
            <AICars />
          </Suspense>
          
          <FollowCamera />
        </Canvas>
        
        <RaceHUD />
        <GameController />
        <SoundManager />
      </KeyboardControls>
    </div>
  );
}

export default App;
